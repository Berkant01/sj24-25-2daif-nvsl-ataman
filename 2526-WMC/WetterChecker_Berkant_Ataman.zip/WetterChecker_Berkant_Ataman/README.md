# Wetter-Checker

Schulprojekt von Berkant Ataman.

## Konzept

Die Website zeigt aktuelles Wetter fuer eine Stadt. Zuerst wird mit `fetch` die Stadt gesucht, danach wird mit einer zweiten `fetch`-Abfrage das aktuelle Wetter geladen.

## Erfuellte Vorgaben

- client-side JavaScript
- `fetch` wird verwendet
- DOM nodes werden erzeugt
- DOM nodes werden geloescht
- DOM nodes werden mit `replaceChild` ausgetauscht
- Arrays kommen in `script.js` und `orte.js` vor
- 3 Seiten: `index.html`, `orte.html`, `info.html`
- einfache Funktionen ohne Frameworks

## Starten

`index.html` im Browser oeffnen.

Optional:

```bash
python3 -m http.server 8080
```

Danach:

```text
http://localhost:8080
```

## API

Open-Meteo:

https://open-meteo.com/
