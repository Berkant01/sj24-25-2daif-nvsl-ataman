var wetterDaten = [];
var beispielStaedte = ["Wien", "Berlin", "Istanbul"];

var stadtInput = document.getElementById("stadtInput");
var suchenButton = document.getElementById("suchenButton");
var beispieleButton = document.getElementById("beispieleButton");
var loeschenButton = document.getElementById("loeschenButton");
var wetterListe = document.getElementById("wetterListe");
var meldung = document.getElementById("meldung");

suchenButton.addEventListener("click", sucheWetter);
beispieleButton.addEventListener("click", ladeBeispiele);
loeschenButton.addEventListener("click", loescheWetter);

function sucheWetter() {
    var stadt = stadtInput.value;

    if (stadt == "") {
        zeigeMeldung("Bitte gib eine Stadt ein.");
    } else {
        zeigeMeldung("Wetter wird geladen...");
        ladeWetterFuerStadt(stadt);
    }
}

function ladeBeispiele() {
    wetterDaten = [];
    leereListe();
    zeigeMeldung("Beispiele werden geladen...");

    for (var i = 0; i < beispielStaedte.length; i++) {
        ladeWetterFuerStadt(beispielStaedte[i]);
    }
}

function ladeWetterFuerStadt(stadt) {
    fetch("https://geocoding-api.open-meteo.com/v1/search?name=" + encodeURIComponent(stadt) + "&count=1&language=de&format=json")
        .then(function(antwort) {
            return antwort.json();
        })
        .then(function(geoDaten) {
            if (!geoDaten.results) {
                zeigeMeldung("Die Stadt wurde nicht gefunden.");
            } else {
                var ort = geoDaten.results[0];
                ladeAktuellesWetter(ort);
            }
        })
        .catch(function() {
            zeigeMeldung("Die Stadt konnte nicht geladen werden.");
        });
}

function ladeAktuellesWetter(ort) {
    var url = "https://api.open-meteo.com/v1/forecast?latitude=" + ort.latitude + "&longitude=" + ort.longitude + "&current_weather=true";

    fetch(url)
        .then(function(antwort) {
            return antwort.json();
        })
        .then(function(daten) {
            var wetterObjekt = {
                name: ort.name,
                land: ort.country,
                temperatur: daten.current_weather.temperature,
                wind: daten.current_weather.windspeed,
                zeit: daten.current_weather.time
            };

            wetterDaten.push(wetterObjekt);
            zeigeWetter();
        })
        .catch(function() {
            zeigeMeldung("Das Wetter konnte nicht geladen werden.");
        });
}

function zeigeWetter() {
    leereListe();

    for (var i = 0; i < wetterDaten.length; i++) {
        var wetter = wetterDaten[i];
        var karte = document.createElement("article");
        var titel = document.createElement("h3");
        var temperatur = document.createElement("p");
        var wind = document.createElement("p");
        var zeit = document.createElement("p");

        karte.className = "weather-card";
        temperatur.className = "temp";

        titel.textContent = wetter.name + ", " + wetter.land;
        temperatur.textContent = wetter.temperatur + " Grad";
        wind.textContent = "Wind: " + wetter.wind + " km/h";
        zeit.textContent = "Zeit: " + wetter.zeit;

        karte.appendChild(titel);
        karte.appendChild(temperatur);
        karte.appendChild(wind);
        karte.appendChild(zeit);
        wetterListe.appendChild(karte);
    }

    zeigeMeldung(wetterDaten.length + " Wetterkarte(n) geladen.");
}

function leereListe() {
    while (wetterListe.firstChild) {
        wetterListe.removeChild(wetterListe.firstChild);
    }
}

function loescheWetter() {
    wetterDaten = [];
    leereListe();
    zeigeMeldung("Alle Wetterkarten wurden geloescht.");
}

function zeigeMeldung(text) {
    meldung.textContent = text;
}
