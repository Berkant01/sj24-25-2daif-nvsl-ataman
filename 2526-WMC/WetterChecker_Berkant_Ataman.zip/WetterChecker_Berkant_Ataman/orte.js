var orte = ["Wien", "Berlin", "Istanbul"];

var ortInput = document.getElementById("ortInput");
var hinzufuegenButton = document.getElementById("hinzufuegenButton");
var ersetzenButton = document.getElementById("ersetzenButton");
var alleLoeschenButton = document.getElementById("alleLoeschenButton");
var orteListe = document.getElementById("orteListe");
var orteMeldung = document.getElementById("orteMeldung");

hinzufuegenButton.addEventListener("click", fuegeOrtHinzu);
ersetzenButton.addEventListener("click", ersetzeErstenOrt);
alleLoeschenButton.addEventListener("click", loescheAlleOrte);

zeigeOrte();

function zeigeOrte() {
    while (orteListe.firstChild) {
        orteListe.removeChild(orteListe.firstChild);
    }

    for (var i = 0; i < orte.length; i++) {
        var eintrag = document.createElement("li");
        var text = document.createElement("span");
        var button = document.createElement("button");

        text.textContent = orte[i];
        button.textContent = "Loeschen";
        button.className = "small-button";
        button.setAttribute("data-index", i);
        button.addEventListener("click", loescheEinOrt);

        eintrag.appendChild(text);
        eintrag.appendChild(button);
        orteListe.appendChild(eintrag);
    }

    orteMeldung.textContent = "Anzahl Orte: " + orte.length;
}

function fuegeOrtHinzu() {
    var neuerOrt = ortInput.value;

    if (neuerOrt == "") {
        orteMeldung.textContent = "Bitte einen Ort eintragen.";
    } else {
        orte.push(neuerOrt);
        ortInput.value = "";
        zeigeOrte();
    }
}

function loescheEinOrt() {
    var index = this.getAttribute("data-index");
    orte.splice(index, 1);
    zeigeOrte();
}

function loescheAlleOrte() {
    orte = [];
    zeigeOrte();
}

function ersetzeErstenOrt() {
    var neuerOrt = ortInput.value;

    if (orte.length == 0) {
        orteMeldung.textContent = "Es gibt keinen Ort zum Ersetzen.";
    } else if (neuerOrt == "") {
        orteMeldung.textContent = "Bitte zuerst einen neuen Ort eintragen.";
    } else {
        orte[0] = neuerOrt;

        var alterEintrag = orteListe.firstChild;
        var neuerEintrag = document.createElement("li");
        var text = document.createElement("span");
        var button = document.createElement("button");

        text.textContent = neuerOrt;
        button.textContent = "Loeschen";
        button.className = "small-button";
        button.setAttribute("data-index", 0);
        button.addEventListener("click", loescheEinOrt);

        neuerEintrag.appendChild(text);
        neuerEintrag.appendChild(button);
        orteListe.replaceChild(neuerEintrag, alterEintrag);

        ortInput.value = "";
        orteMeldung.textContent = "Der erste Ort wurde ersetzt.";
    }
}
